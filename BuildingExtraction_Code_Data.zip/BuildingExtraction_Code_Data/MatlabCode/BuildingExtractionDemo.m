% Building Contour Completion

close all
clear

Image_dir = dir('..\Dataset\image_data\*.jpg');
Image_path = '..\Dataset\image_data\';

% figure(1)
for i = 1:length(Image_dir)
    close all
    tic
    fprintf(['image: ',int2str(i),'/',int2str(length(Image_dir)),'\n']);
    %read image
    I = imread([Image_path,Image_dir(i).name]);
    
%     imshow(I);
%     hold on
    
    lineSegments = EDLines(I, 1);
    noLines = size(lineSegments, 1);
    
    lines = zeros(noLines,4);
    sx = [lineSegments.sx];
    sy = [lineSegments.sy];
    ex = [lineSegments.ex];
    ey = [lineSegments.ey];
    lines = [sx',sy',ex',ey'];
    clear sx sy ex ey lineSegments
    
    fprintf('Delaunay Triangulation...\n');
    X = zeros(length(lines),2);
    Y = zeros(length(lines),2);
    X = [double(lines(:,1));double(lines(:,3))];
    Y = [double(lines(:,2));double(lines(:,4))];
    
    T = delaunayTriangulation(X,Y);
    
%     triplot(T,'LineWidth',3);
%     for iii = 1:noLines
%         plot([lines(iii,1) lines(iii,3)], [lines(iii,2) lines(iii,4)], 'r-','LineWidth',4);
%     end
%     hold on
%     plot(X,Y,'g.','MarkerSize',8);
    
    
    XYT = T.Points;
    XYO = [X,Y];
    [~,iT,iO] = intersect(T.Points,XYO,'rows');
    
    Len_Mat = zeros(length(T.Points),length(T.Points));
    
    ed_num = 0;
    for it = 1:length(lines)
        if ~isempty(find(it==iO))&&~isempty(find((it+length(lines))==iO))
            ed_num = ed_num + 1;
            ed_edges(ed_num,1) = iT(find(it==iO));
            ed_edges(ed_num,2) = iT(find((it+length(lines))==iO));
            
            Len_Mat(ed_edges(ed_num,1),ed_edges(ed_num,2)) = pdist([T.Points(ed_edges(ed_num,1),:);...
                T.Points(ed_edges(ed_num,2),:)]);
            
        end
    end
    
    tri_edges = edges(T);
    
    tin_edges = setdiff(tri_edges,ed_edges,'rows');
    tin_edges = setdiff(tin_edges,[ed_edges(:,2),ed_edges(:,1)],'rows');
    
%     clear X Y XYT XYO
    
    fprintf('Weights from Distance Transform Image...\n');
% % % %     if length(size(I))>2
% % % %         img_edge = edge(rgb2gray(I),'canny');
% % % %     else
% % % %         img_edge = edge(I,'canny');
% % % %     end
% % % %     % img = im2bw(img);
% % % %     img_edge = bwdist(img_edge,'euclidean');
    
%     DT_profile = cell(length(tin_edges),1);
    DT_profile_weights = zeros(length(tin_edges),1);
    %generate topology from delaunay triangulation
    tin_edges_len = zeros(length(tin_edges),1);
    for ii = 1:length(tin_edges)
        tmpP(1,:) = [T.Points(tin_edges(ii,1),1),T.Points(tin_edges(ii,1),2)];
        tmpP(2,:) = [T.Points(tin_edges(ii,2),1),T.Points(tin_edges(ii,2),2)];
        tin_edges_len(ii) = pdist(tmpP);
        tmpP(tmpP<1) = 1;
%         DT_profile{ii,1} = improfile(img_edge,tmpP(:,1),tmpP(:,2));
        DT_profile_weights(ii) = tin_edges_len(ii);%sum(DT_profile{ii,1});
        %    DT_profile_weights(i)  = tin_edges_len(i);
        Len_Mat(tin_edges(ii,1),tin_edges(ii,2)) = pdist(tmpP);
        
    end
    
    Len_Mat = Len_Mat + Len_Mat';
  
    fprintf('Contour Completion by Shortest Path Searching...\n');
    g = zeros(size(T.Points,1),size(T.Points,1));
    
 
    for j = 1:length(ed_edges)%edges in extracted straight lines
        g(ed_edges(j,1),ed_edges(j,2)) = 1e-5;
%         Sr(j) = ed_edges(j,1);
%         Tg(j) = ed_edges(j,2);
    end
    
    for k = 1:length(tin_edges)%edges of triangulation generated
%           g(tin_edges(k,1),tin_edges(k,2)) = DT_profile_weights(k);
          g(tin_edges(k,1),tin_edges(k,2)) = Len_Mat(tin_edges(k,1),tin_edges(k,2));
    end
    
    g = g + g';
    G = sparse(g);
    clear g
    
    DIST_S = zeros(length(ed_edges),length(T.Points));
    DIST_T = zeros(length(ed_edges),length(T.Points));
    PATH_S = cell(length(ed_edges),1);
    PATH_T = cell(length(ed_edges),1);
    
    for p = 1:length(ed_edges)
        G(ed_edges(p,1),ed_edges(p,2)) = 100000;
        G(ed_edges(p,2),ed_edges(p,1)) = 100000;
        [dist_s,path_s,~] = graphshortestpath(G,ed_edges(p,1),'Method','Dijkstra');
        [dist_t,path_t,~] = graphshortestpath(G,ed_edges(p,2),'Method','Dijkstra');
       
   
        %==========draw current line segment===========
%         for jj = 1:length(path_s)
%             jj
%             figure(2)
%             imshow(I);
%             hold on
%             triplot(T,'LineWidth',3);
% %             for iii = 1:noLines
% %                 plot([lines(iii,1) lines(iii,3)], [lines(iii,2) lines(iii,4)], 'r-','LineWidth',4);
% %             end
%             hold on
%             plot(X,Y,'g.','MarkerSize',8);
%             
%             path_s{jj}(1)
%             path_t{jj}(1)
%             p1 = T.Points(path_s{jj}(1),:);
%             p2 = T.Points(path_t{jj}(1),:);
%             plot([p1(1),p2(1)],[p1(2),p2(2)],'r-','LineWidth',4);
%             hold on
%             
%             if length(path_s{jj})>1 && length(path_t{jj})>1
%                 
%                 ps = T.Points(path_s{jj},:);
%                 plot(ps(:,1),ps(:,2),'g-','LineWidth',4);
%                 
%                 pt = T.Points(path_t{jj},:);
%                 plot(pt(:,1),pt(:,2),'y-','LineWidth',4);
%             end
%             hold off
%             pause;
%         end
        
        DIST_S(p,:) = dist_s;
        DIST_T(p,:) = dist_t;
        
        PATH_S{p} = path_s;
        PATH_T{p} = path_t;
    end
    clear G
    
    path_length = zeros(length(ed_edges),length(T.Points));
    PolyArea = zeros(length(ed_edges),length(T.Points));
    W = zeros(length(ed_edges),length(T.Points));
    PATH_ALL = cell(length(ed_edges),length(T.Points));
    
    for t = 1:length(PATH_S)
        for p = 1:length(PATH_S{t})
            
%             plot([T.Points(tmpPt_idx(Sr(t)),1),T.Points(tmpPt_idx(Tg(t)),1)],...
%                 [T.Points(tmpPt_idx(Sr(t)),2),T.Points(tmpPt_idx(Tg(t)),2)],'g-','LineWidth',3);
            
            if length(intersect(cell2mat(PATH_S{t}(p)),cell2mat(PATH_T{t}(p))))==1
                if ~isempty(PATH_S{t}(p))&&~isempty(PATH_T{t}(p))
                    path_s = cell2mat(PATH_S{t}(p));
                    path_t = flip(cell2mat(PATH_T{t}(p)));
                    path = [path_s,path_t(2:end)];
                    
                    PATH_ALL{t,p} = path;
                    
                    PolyArea(t,p) = polyarea(T.Points(path,1),T.Points(path,2));
                    for tt = 1:length(path)
                        if tt<length(path)
                            path_length(t,p) = path_length(t,p) + Len_Mat(path(tt),path(tt+1));
                            %pdist([T.Points(path(tt));T.Points(path(tt+1))]);
                        else
                            path_length(t,p) = path_length(t,p) + Len_Mat(path(1),path(tt));
                            %pdist([T.Points(path(1));T.Points(path(tt))]);
                        end
                    end
                end
            else
                path_length(t,p) = 1e-10;
            end
            clear path
        end
        fprintf(['building id: ',int2str(i),', line: ', int2str(t),'/',int2str(length(PATH_S)),'\n']);
    end
    
    W = (DIST_S+DIST_T)./PolyArea;%path_length
    [w1,r] = min(W);
    clear W
    [~,c] = min(w1);
    clear w1
    
    
        
% % %     figure(1)
% % %     imshow(I);
% % %     hold on
% % %     

% % %     
% % %     plot([T.Points(ed_edges(r(c),1),1),T.Points(ed_edges(r(c),2),1)],...
% % %         [T.Points(ed_edges(r(c),1),2),T.Points(ed_edges(r(c),2),2)],'g-','LineWidth',2);
% % %     hold on;
% % %     if ~isempty(PATH_S{r(c)}(c))
% % %         path_pt_s = T.Points(cell2mat(PATH_S{r(c)}(c)),:);
% % %         plot(path_pt_s(:,1),path_pt_s(:,2),'r-','LineWidth',2);
% % %         hold on
% % %     end
% % %     if ~isempty(PATH_T{r(c)}(c))
% % %         path_pt_t = T.Points(cell2mat(PATH_T{r(c)}(c)),:);
% % %         plot(path_pt_t(:,1),path_pt_t(:,2),'b-','LineWidth',2);
% % %         hold on
% % %     end
    
    tmpPts = T.Points(PATH_ALL{r(c),c},:);
    tmpPts = tmpPts';
    tmpPts = reshape(tmpPts,size(tmpPts,1)*size(tmpPts,2),1);
    tmpPts = tmpPts';
    
    img_re = insertShape(I,'Line',lines,'LineWidth',2,'Color','red','SmoothEdges',false);
    
    X = tmpPts(1:2:end);
    Y = tmpPts(2:2:end);
    X = [X,X(1)];
    Y = [Y,Y(1)];
    Xs = X(1:end-1);
    Ys = Y(1:end-1);
    Xe = X(2:end);
    Ye = Y(2:end);
    L = [Xs;Ys;Xe;Ye];
    L = L';
    img_re = insertShape(img_re,'Line',L,'LineWidth',4,'Color','green','SmoothEdges',false);
    %img_re = insertShape(img_re,'Polygon',tmpPts,'LineWidth',4,'Color','green','SmoothEdges',false);
    imwrite(img_re,[Image_path(1:end-11),'..\Results\results_outline\',Image_dir(i).name(1:end-4),'.bmp']);
    
    img_ze = zeros(size(I,1),size(I,2));
    img_ze = insertShape(img_ze,'FilledPolygon',tmpPts,'Color','white','Opacity',1,'SmoothEdges',false);
    imwrite(img_ze,[Image_path(1:end-11),'..\Results\results_region\',Image_dir(i).name(1:end-4),'.bmp']);
    
    clear r c ed_edges tin_edges tmpPts img_re img_ze
    
% %     imshow(I);
% %     hold on;
% %     
% %     for i = 1:noLines
% %         plot([lineSegments(i).sx lineSegments(i).ex], [lineSegments(i).sy lineSegments(i).ey], 'r-','LineWidth',2);
% %     end
    toc
%     pause;
%%%%break;
%     hold off
    
end





