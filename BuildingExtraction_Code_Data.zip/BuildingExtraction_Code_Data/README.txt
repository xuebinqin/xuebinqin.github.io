Our building extraction code uses EDLines[1] as line segments detectors and it is tested on win7 x64 OS.

1. To run it, go to the "MatlabCode" folder and run "BuildingExtractionDemo.m".
(If it does not work, try to double click "vcredist_x64.exe" in "BuildingExtraction_Code_Data" folder and run it again.)

2. The "BuildingExtractionDemo.m" will read images one by one from "Dataset\image_data".

3. The results of outlines and regions will be output to "Results\results_outline" and "Results\results_region" respectively.

4. The "Dataset\groundtruth" folder contains all the ground truth of the images in "Dataset\image_data".

[1]C. Topal, C. Akinlar, and Y. Genc, Edge Drawing: A Heuristic Approach to Robust Real-Time Edge Detection, 
Proceedings of the ICPR, pp. 2424-2427, August 2010.